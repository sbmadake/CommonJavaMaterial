# spring-boot-CRUD-with-thymeleaf

  [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

spring boot thymeleaf CRUD example.
create Database crud_101 in mysql.

set MYSQL user and password in application.properties file.

Run: localhost:8080


# Welcome Page

  ![](img/one.png)
  
  
# Main Page
  ![](img/two.png)
  
# Add Course 
  ![](img/three.png)
  
# Update Course
  ![](img/four.png)
  
  

